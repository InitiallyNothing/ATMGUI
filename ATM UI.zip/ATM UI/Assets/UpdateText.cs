﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UpdateText : MonoBehaviour {
    public Text password;
    public int changedScene;
    public Text wrong;
    int count = 0;
    
    public void Button_OnClick1()
    {
        password.text = password.text + "1";
    }
    public void Button_OnClick2()
    {
        password.text = password.text + "2";
    }
    public void Button_OnClick3()
    {
        password.text = password.text + "3";
    }
    public void Button_OnClick4()
    {
        password.text = password.text + "4";
    }
    public void Button_OnClick5()
    {
        password.text = password.text + "5";
    }
    public void Button_OnClick6()
    {
        password.text = password.text + "6";
    }
    public void Button_OnClick7()
    {
        password.text = password.text + "7";
    }
    public void Button_OnClick8()
    {
        password.text = password.text + "8";
    }
    public void Button_OnClick9()
    {
        password.text = password.text + "9";
    }
    public void Button_OnClick0()
    {
        password.text = password.text + "0";
    }
    public void Button_OnClickBack()
    {   
        if(password.text.Length != 0)
        password.text = password.text.Substring(0, password.text.Length - 1);
    }
    public void Button_OnClickEnter()
    {
        if (password.text.Equals("12345"))
        {
            SceneManager.LoadScene(changedScene);
        }
        else
        {
            count++;
            wrong.text = "Wrong Password count: " + count;
        }
    }
}

