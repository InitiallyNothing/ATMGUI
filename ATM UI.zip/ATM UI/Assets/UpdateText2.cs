﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class UpdateText2 : MonoBehaviour
{
    public Text password;
    public int changedScene;
    public Text wrong;
    public Text accountBalance;
    public static int AccountBalance = 15;
    public static int MaxWithdrawCap = 15;
    public int completeSum;
    ArrayList numbers = new ArrayList();

    public void Button_OnClick1()
    {
        password.text = password.text + "1";
        numbers.Add(1);
        wrong.text = "";
    }
    public void Button_OnClick2()
    {
        password.text = password.text + "2";
        numbers.Add(2);
        wrong.text = "";
    }
    public void Button_OnClick3()
    {
        password.text = password.text + "3";
        numbers.Add(3);
        wrong.text = "";
    }
    public void Button_OnClick4()
    {
        password.text = password.text + "4";
        numbers.Add(4);
        wrong.text = "";
    }
    public void Button_OnClick5()
    {
        password.text = password.text + "5";
        numbers.Add(5);
        wrong.text = "";
    }
    public void Button_OnClick6()
    {
        password.text = password.text + "6";
        numbers.Add(6);
        wrong.text = "";
    }
    public void Button_OnClick7()
    {
        password.text = password.text + "7";
        numbers.Add(7);
        wrong.text = "";
    }
    public void Button_OnClick8()
    {
        password.text = password.text + "8";
        numbers.Add(8);
        wrong.text = "";
    }
    public void Button_OnClick9()
    {
        password.text = password.text + "9";
        numbers.Add(9);
        wrong.text = "";
    }
    public void Button_OnClick0()
    {
        password.text = password.text + "0";
        numbers.Add(0);
        wrong.text = "";
    }
    public void Button_OnClickQuickWithdraw1()
    {
        if (MaxWithdrawCap - 1 < 0)
        {
            wrong.text = "You can't quick withdraw 1";
        }
        if (MaxWithdrawCap - 1 >= 0)
        {
            MaxWithdrawCap = MaxWithdrawCap - 1;
            AccountBalance = AccountBalance - 1;
            accountBalance.text = "Account Balance:" + AccountBalance;
            wrong.text = "";
        }
    }
    public void Button_OnClickQuickWithdraw5()
    {
        if (MaxWithdrawCap - 5 < 0)
        {
            wrong.text = "You can't quick withdraw 5";
        }
        if (MaxWithdrawCap - 5 >= 0)
        {
            MaxWithdrawCap = MaxWithdrawCap - 5;
            AccountBalance = AccountBalance - 5;
            accountBalance.text = "Account Balance:" + AccountBalance;
            wrong.text = "";
        }
  
    }

    public void Button_OnClickQuickWithdraw10()
    {
        if (MaxWithdrawCap - 10 < 0)
        {
            wrong.text = "You can't quick withdraw 10";
        }
        if (MaxWithdrawCap - 10 >= 0)
        {
            MaxWithdrawCap = MaxWithdrawCap - 10;
            AccountBalance = AccountBalance - 10;
            accountBalance.text = "Account Balance:" + AccountBalance;
            wrong.text = "";
        }
     
    }

    public void Button_OnClickQuickWithdraw15()
    {
        if (MaxWithdrawCap - 15 < 0)
        {
            wrong.text = "You can't quick withdraw 15";
        }
        if (MaxWithdrawCap - 15 >= 0)
        {
            MaxWithdrawCap = MaxWithdrawCap - 15;
            AccountBalance = AccountBalance - 15;
            accountBalance.text = "Account Balance:" + AccountBalance;
            wrong.text = "";
        }
    }

    public void Button_OnClickBack()
    {
        if (password.text.Length != 0)
        {
            password.text = password.text.Substring(0, password.text.Length - 1);
            numbers.RemoveAt(numbers.Count - 1);
            wrong.text = "";
        }
          
    }

    public void Button_OnClickWithdraw()
    {
        int.TryParse(password.text,out completeSum);  
        if(completeSum > MaxWithdrawCap)
        {
            wrong.text = "Exceeds Limit";
        }
        if (completeSum <= MaxWithdrawCap)
        {
            MaxWithdrawCap = MaxWithdrawCap - completeSum;
            AccountBalance = AccountBalance - completeSum;
            accountBalance.text = "Account Balance:" + AccountBalance;
            wrong.text = "";
        }
        numbers = new ArrayList();
        completeSum = 0;
        password.text = "";
        
    }
    public void Button_OnClickDeposit()
    {
        int.TryParse(password.text, out completeSum);
        AccountBalance = AccountBalance + completeSum;
        accountBalance.text = "Account Balance:" + AccountBalance;
        numbers = new ArrayList();
        completeSum = 0;
        password.text = "";
        wrong.text = "";
    }
}

